## Repositório com códigos dos Reels

### Para mais conteúdo, siga o @programador.cs no instagram.

Clique na imagem para ser redirecionado ao código:

Click on the image to be redirected to the code:

<p float="left">

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/card-stranger-things">
  <img src="https://user-images.githubusercontent.com/28737079/178617830-67ae662f-1607-4e72-b349-f62bd7a2f243.PNG" width="300" />
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/logo-stranger-things">
  <img src="https://user-images.githubusercontent.com/28737079/178618812-5bebee1a-7753-4bbd-852c-8ff6835b8d5a.PNG" width="300" /> 
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/slider-produtos-simples">
  <img src="https://user-images.githubusercontent.com/28737079/178620754-3a66cbee-368b-4495-bb9d-7140276a9201.png" width="300" />
</a>

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/botao-borda-linear">
    <img src="https://user-images.githubusercontent.com/28737079/178618497-4b5aa23e-f101-455b-9ff8-3ca47675c1a9.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/cards-efeito-vento">
    <img src="https://user-images.githubusercontent.com/28737079/178618627-f133a537-a78b-4c9d-b726-e9bd64672dd7.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/search-com-html-puro">
    <img src="https://user-images.githubusercontent.com/28737079/178618920-85d18275-eb21-438d-8074-5ae986288d40.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/color-background-text">
    <img src="https://user-images.githubusercontent.com/28737079/178619074-a568b0c1-3386-4df9-b122-81309a508910.PNG"  width="300"/>
</a>
<a href="">
    <img src="https://user-images.githubusercontent.com/28737079/178619283-47331c8b-98ee-4b67-b0b6-8909208d8df0.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/efeito-pulsante">
    <img src="https://user-images.githubusercontent.com/28737079/178619449-e4376201-52cd-40e5-95b1-82e97a0dd00b.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/button-com-loader">
    <img src="https://user-images.githubusercontent.com/28737079/178619603-4f597f22-b87f-4fb1-a746-f077c30ca2e8.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/cards-estilo-twitter">
    <img src="https://user-images.githubusercontent.com/28737079/178619781-972e0e5e-2256-4e78-ae0c-8cfd3f1da610.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/ideias-de-botoes-para-CTA">
    <img src="https://user-images.githubusercontent.com/28737079/178973630-a3df21e4-cdc6-4594-bf2e-a070d7dec1b8.png"  width="300"/>
</a>
<p>
    <img src="https://user-images.githubusercontent.com/28737079/179079455-6217b727-8cb7-42fe-8bda-c8d4f576f9f5.png" width="300"/>

- [1](https://github.com/Cassianosch/programador.cs-reels/tree/master/checkbox-rouded)
- [2](https://github.com/Cassianosch/programador.cs-reels/tree/master/button-checkbox)
- [3, 4, 5](https://github.com/Cassianosch/programador.cs-reels/tree/master/loading-button-text-popping)
- [6](https://github.com/Cassianosch/programador.cs-reels/tree/master/detalhe-fita)
</p>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/flexbox">
    <img src="https://user-images.githubusercontent.com/28737079/180332588-eaccefae-07c6-48af-bcb7-ee09185b3ebe.png"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/fullscreen-slider">
    <img src="https://user-images.githubusercontent.com/28737079/181121942-4716a188-61b3-42e4-af52-76cd4077462e.jpg"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/relogio-embacado">
    <img src="https://user-images.githubusercontent.com/28737079/181121991-5dc6d8bf-bcb8-4175-9273-332446761674.jpg"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/dicionario-online">
    <img src="https://user-images.githubusercontent.com/28737079/182258227-f0b51f0b-99c7-49df-977e-754be60e5a13.jpg"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-scroll-snap">
    <img src="https://user-images.githubusercontent.com/28737079/183213663-f58378d3-e650-4a02-afb3-18802a69f4c2.jpeg"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-selection">
    <img src="https://user-images.githubusercontent.com/28737079/183527676-2831b9b0-c405-4925-8765-c415248bbdf3.png"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-efeito-hover-progressivo">
    <img src="https://user-images.githubusercontent.com/28737079/184510621-b6524b63-f6ec-4ebd-b836-96416fce5538.png"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/calculadora">
    <img src="https://user-images.githubusercontent.com/28737079/185515060-54cee494-f038-4ae1-baa0-5505e95bf7a1.png"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/icones-flutuantes">
    <img src="https://user-images.githubusercontent.com/28737079/186989855-f147376d-19c3-4ab1-8fd9-e9b6b2824643.png"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/pagina-login">
    <img src="https://user-images.githubusercontent.com/28737079/186989883-ff63b2e5-0c1a-4ce0-9031-69098d1841c4.png"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-cursor-imagem">
    <img src="https://user-images.githubusercontent.com/28737079/187558844-84fae9b1-17e3-4c9d-861c-11c01ca97875.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/titulo-efeito-espacamento">
    <img src="https://user-images.githubusercontent.com/28737079/187558875-f7c2ab4f-fa6d-4b8d-832a-56d50a73e094.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/caixa-borda-arco-iris">
    <img src="https://user-images.githubusercontent.com/28737079/187558903-59ac2a66-542e-4fb1-9144-ba27fa4c04cd.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/card-rotacao">
    <img src="https://user-images.githubusercontent.com/28737079/192057922-997bb682-0e11-47ce-8ec0-e037aa71fe8d.jpg"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/colunas-responsivas">
    <img src="https://user-images.githubusercontent.com/28737079/187558940-993bad38-ecf2-4eb2-a00e-f137edad4405.PNG"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/carrosel-css-grid">
    <img src="https://user-images.githubusercontent.com/28737079/192892225-b94824f5-5721-49c9-ae9c-34eb73aa0a4c.jpg"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-botao-curtir-efeito-abertura">
    <img src="https://user-images.githubusercontent.com/28737079/198004361-281e6d6f-2f45-4397-85bc-87778d998855.jpg"  width="300"/>
</a>

<!-- <a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/fotos-responsivas">
    <img src="https://user-images.githubusercontent.com/28737079/198894427-32f3a748-bc1c-4a9e-8c8c-e155c213d755.jpg"  width="300"/>
</a> -->

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/button-com-salto-alt">
    <img src="https://user-images.githubusercontent.com/28737079/198894406-3acec46c-b36a-4f61-887f-d0bf73473aad.jpg"  width="300"/>
</a>

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/button-com-salto">
    <img src="https://user-images.githubusercontent.com/28737079/198894420-0958507c-1af1-4f22-a2ee-dfe194e6cae1.jpg"  width="300"/>
</a>

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-modo-claro-escuro-chartjs">
    <img src="https://user-images.githubusercontent.com/28737079/199854820-8fbc8b0a-28c0-4410-86f7-bf4458802c85.jpg"  width="300"/>
</a>

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/carrosel-css-giratorio">
    <img src="https://user-images.githubusercontent.com/28737079/199866388-0b43b8bb-54c1-49f3-b790-ddc22cf0e0b2.png"  width="300"/>
</a>
<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/bomba-nuclear">
    <img src="https://user-images.githubusercontent.com/28737079/200124631-5294b7ec-d83c-4c95-a210-bf7bf517e3cc.jpg"  width="300"/>
</a>

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-menu-lampada">
    <img src="https://user-images.githubusercontent.com/28737079/200449817-26aea741-24e1-4723-8c13-a70d0effab20.png"  width="300"/>
</a>

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/cartao-credito-rotacao">
    <img src="https://user-images.githubusercontent.com/28737079/201206407-87a5c270-d75d-4c2a-b29f-2084d102d942.jpg"  width="300"/>
</a>

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-cards-com-hover">
    <img src="https://user-images.githubusercontent.com/28737079/201206336-ec42cc1a-6ae9-40da-bb2c-c034087a94ed.jpg"  width="300"/>
</a>

<!-- <a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-botao-cor-perseguida">
    <img src="https://user-images.githubusercontent.com/28737079/201209148-a218a23b-8e39-42cb-8847-eeb98fd57645.jpg"  width="300"/>
</a> -->

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/fifa-wc-2022">
    <img src="https://user-images.githubusercontent.com/28737079/204312378-abd3dd3c-0877-4934-91ba-bfacc687ab98.png"  width="300"/>
</a>

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/slider-roda-wfc">
    <img src="https://user-images.githubusercontent.com/28737079/206733281-163b7920-355f-4482-978e-af5ef1701db2.jpg"  width="300"/>
</a>

<a href="https://github.com/Cassianosch/programador.cs-reels/tree/master/css-menu-hover-fullscreen">
    <img src="https://user-images.githubusercontent.com/28737079/200430786-47dc3c98-89eb-4240-9d82-6a0b2b6ccb5f.png"  width="300"/>
</a>

</p>

- Neste repositório será inserido os códigos dos reels postados no perfil do instagram.
- Os projetos dentro do repositório estão organizados em pastas com o mesmo título da postagem.
- Sinta-se livre utilizar os códigos.
