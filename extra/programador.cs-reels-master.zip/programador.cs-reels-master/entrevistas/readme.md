## Perguntas e respostas sobre tecnologias

Esta pasta contém uma série de perguntas e respostas para lhe ajudar compreender melhor o funcionamento das tecnologias, podendo estudar e se preparar para entrevistas/conhecimento/dúvidas gerais

- irei preenchendo as perguntas mais comuns em entrevistas
- o meu objetivo com isso é lhe ajudar a estudar antes de entrevistas técnicas/conhecimento/dúvidas gerais
- será preenchido com mais questão ao passar do tempo
- caso queira contribuir, faça um fork/pr, me envie mensagem no instagram etc

### pt-BR

[HTML](https://github.com/Cassianosch/programador.cs-reels/tree/master/entrevistas/html)  
[CSS](https://github.com/Cassianosch/programador.cs-reels/tree/master/entrevistas/css)  
[Javascript](https://github.com/Cassianosch/programador.cs-reels/tree/master/entrevistas/javascript)  
[React](https://github.com/Cassianosch/programador.cs-reels/tree/master/entrevistas/react)

### US

Soon...

Nota: Lembre que muitas as perguntas e respostas são bem objetivas, mas você pode explicar um pouco melhor, levando a uma discusão interessante.
