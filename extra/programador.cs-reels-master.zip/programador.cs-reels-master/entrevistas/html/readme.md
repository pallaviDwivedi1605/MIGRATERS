#### O que é a DOM?

A DOM é a representação do HTML que vemos na página, ela é definida por nós(nodes) e objetos e com isso podemos modifica-la.

#### O que são as meta tags?

As meta tags são específicações do nosso website que ajudam os nevegadores e buscadores(google, yahoo etc) a entender o conteúdo daquela página em específico, podendo ser definidido também algumas coisas visuais como título da página, favicon etc.

#### O que é um iframe?

Um iframe é uma tag que possibilidade incorporarmos outra página ou conteúdo dentro de um website.

#### Para que serve o atributo alt?

O atributo alt funciona como um fallback(modo de falha) quando algo não da certo, muito utilizados em imagens quando a mesma não abrir o texto dentro do atributo alt será mostrado, assim melhorando a experiência do usuário.

#### Qual a diferença entre span e div?

div - elemento blocante
span - elemento inline

#### Qual a diferença entre as especificações da pergunta anterior?

Blocante - É um elemento que quebra uma linha e que é possível definir um tamanho (largura e altura)  
Inline - É um elemento que não quebra uma linha e que não é possível definir um tamanho (largura e altura)

#### De exemplos sobre a pergunta anterior?

blocante - div, p, títulos
inline - imagens, span, b

#### existe alguma forma de utilizarmos os dois tipos em um só?

Com a disposição inline-block você irá obter um elemento inline-blocante que suportará outros elementos alinhados horizantalmente e poderá definir um tamanho nele

#### Diga alguma das tags semanticas do html5?

header, nav, footer, main

#### Descreva so alguma das tags(aonde usar, qual o sentido de usar)?

header, nav, footer, main

#### Como posso melhorar o SEO de um website?

Utilizando botas práticos com títulos de textos. Utilizando as keywords e descriptions nas meta tags são algumas das formas de melhorar o SEO de um website.
