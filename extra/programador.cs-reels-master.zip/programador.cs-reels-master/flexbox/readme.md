#### Flexbox

Códigos utilizados nos vídeos.

Link da aula: [https://www.youtube.com/playlist?list=PLllQzCld5ufjGNvx3GdX8VJKvPjqw2dI\_](https://www.youtube.com/playlist?list=PLllQzCld5ufjGNvx3GdX8VJKvPjqw2dI_)

- 1 - Flexbox - flex - Parte 1
- 2 - Flexbox - flex-direction - Parte 2
- 3 - Flexbox - flexwrap - Parte 3
- 4 - Flexbox - order - Parte 4
- 5 - Flexbox - justify-content - Parte 5
- 6 - Flexbox - align-items - Parte 6
- 7 - Flexbox - align-content - Parte 7
- 8 - Flexbox - align-self - Parte 8
- 9 - Flexbox - flex - Parte 9
- 10 - Flexbox - flex - Parte 10
- 11 - Flexbox - flex-flow - Parte 11
- 12 - Flexbox - gap - Parte 12
