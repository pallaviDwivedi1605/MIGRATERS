#### Fullscreen Slider

- Os códigos foram encontrados na internet, e reformulados conforme a arte necessitava.
- As imagens foram retiradas do website unsplash.com.
- Neste repositório será inserido os códigos dos reels postados no perfil do instagram.
- Os projetos dentro do repositório estão organizados em pastas com o mesmo título da postagem.
- Sinta-se livre utilizar os códigos.
